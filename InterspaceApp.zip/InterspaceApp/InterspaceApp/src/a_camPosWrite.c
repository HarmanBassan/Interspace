#include <epicsStdlib.h>
#include <epicsStdioRedirect.h>
#include <epicsMath.h>
#include <dbAccess.h>
#include <dbEvent.h>
#include <dbDefs.h>
#include <recGbl.h>
#include <dbCommon.h>
#include <registryFunction.h>
#include <epicsExport.h>
#include <recSup.h>
#include <aSubRecord.h>
#include <pinfo.h>
#include <alarm.h>

#define PI 3.141592653
#define DEBUG 0

double rad2deg(double x) {
	return (x*180.0)/PI;
}


/* FUNCTIONS FOR INVERSE KINEMATICS: FROM US, DS, AND QUAD CARTESIAN POSITION TO CAM ANGLES
Results obtained solving the following linear system (ex for upstream, cams 2 and 3)
_              _    _         _    _    _             _                    _
| e2*sin(phi2)  |  | u2x  u2y  |  | Tux  |           |  u2 dot (z cross r2) |
| e3*sin(phi3)  | =| u3x  u3y  |* | Tuy  | + theta * |  u3 dot (z cross r3) |
|_             _|  |_         _|  |_    _|           |_                    _|


[ EP23 ] = [ A23 ] * [ TUS ] + theta * [ TH23] 

Where: Tusx and Tusy are upsteam x and y compoments of the displacement
u2 = [ u2x u2y ] unit vector cam 2 surface normal. u2x = u2y = 1/sqrt(2)
u3 = [ u3x u3y ] unit vector cam 3 surface normal. u3x = -u2y = 1/sqrt(2)
e2, e3 = cams eccentricity
phi2, phi3 = cams roation angles
theta = roll angle (rotation around z axis)
z = [0 0 1 ] unit vector
r2 = [r2x r2y] position of cam 2 point of contact
r3 = [r3x r3y] position of cam 3 point of contact
The origin of the frame is in the quadrupole magnet, with z along the beam and y up

NOTE:
r23y is the result of row 1 of [ A23 ]-1 * [ TH23 ]
r23x is the result of row 2 of [ A23 ]-1 * [ TH23 ]

Similarly for downstream cams 4 and 5
*/

/* General formula for upstream and downstream translation from 
translation of the center*/
double T(double x, double g, double z){

	double f = x + g/1000.*z;
	return f;
}

/* Y displacement of cam 1 contact point, th is roll (z) angle*/
double contact1y(double y, double ps, double zp2, double zrel, double zp4, double th, double rp1x){
	double f = T(y,ps,zp2)*zrel + T(y,ps,zp4)*(1-zrel) + th/1000.*rp1x;
	if (DEBUG)
	{
		printf("\ncontact1y: %f",f);
	}
	return f;
}

/* Y displacement of system of cams 2 and 3 contact point, ps is pitch (x) angle */
double contact23y(double y, double ps, double zp2, double th, double r23x){
        /* Upstream y displacement from displacement of center + pitch rotation */
	double Tusy = T(y,ps,zp2); 
	double ct = Tusy+th/1000.*r23x;
	if (DEBUG)
	{
		printf("\nTusy: %f",Tusy);
		printf("\ncontact23y: %f",ct);
	}
	return ct;
}

/* X displacement of system of cams 2 and 3 contact point, ga is  yaw (y) angle */
double contact23x(double x, double ga, double zp2, double th, double r23y){
        /* Upstream x displacement from displacement of center + yaw rotation */
	double Tusx = T(x,ga,zp2);
	double ct = Tusx-th/1000.*r23y;
	if (DEBUG)
	{
		printf("\nTusx: %f",Tusx);
		printf("\ncontact23x: %f",ct);
	}
	return ct;
}

/* Y displacement of system of cams 4 and 5 contact point, ps is pitch (x) angle */
double contact45y(double y, double ps, double zp4, double th, double r45x){
        /* Downstream y displacement from displacement of center + pitch rotation */
	double Tdsy = T(y,ps,zp4);
	double ct = Tdsy+th/1000.*r45x;
	if (DEBUG)
	{
		printf("\nTusy: %f",Tdsy);
		printf("\ncontact45y: %f",ct);
	}
	return ct;
}

/* X displacement of system of cams 4 and 5, ga is  yaw (y) angle */
double contact45x(double x, double ga, double zp4, double th, double r45y){
        /* Downstream x displacement from displacement of center + pitch rotation */
	double Tdsx = T(x,ga,zp4);
	double ct = Tdsx-th/1000.*r45y;
	if (DEBUG)
	{
		printf("\nTusx: %f",Tdsx);
		printf("\ncontact45x: %f",ct);
	}
	return ct;
}

/* Calculate how much to move (angle) cam 1 motion only along y*/
/* Based on desired y, roll and pitch angles */
/* contact1y = e1 * sin(ph1) */
double calcPhi1 (double y, double ps, double zp2, double zrel, double zp4, double th, double rp1x, double e1){
	double ph1 = asin(contact1y(y, ps, zp2, zrel, zp4, th, rp1x)/fabs(e1));
	if (DEBUG)
	{
		printf("\nPhi1: %f", ph1);
	}
	return ph1;
}

/* Caculate how much to move (angle) cam 2 
 Based on desired x, y, roll, pitch, and yaw. 

Result derives from Row 1 of [ EP23 ] = [ A23 ] * [ TUS ] + theta * [ TH23 ]*/ 
double calcPhi2 (double y, double ps, double zp2, double th, double r23x, double x, double ga, double r23y, double e2){
	double ph1 = asin((contact23y(y,ps,zp2,th,r23x) + contact23x(x,ga,zp2,th,r23y))/(sqrt(2)*fabs(e2)));
		if (DEBUG)
	{
		printf("\nPhi2: %f", ph1);
	}
	return ph1;
}

/* Caculate how much to move (angle) cam 3 
 Based on desired x, y, roll, pitch, and yaw. 

Result derives from Row 2 of [ EP23 ] = [ A23 ] * [ TUS ] + theta * [ TH23 ]*/ 
double calcPhi3 (double y, double ps, double zp2, double th, double r23x, double x, double ga, double r23y, double e3){
	double ph1 = asin((contact23y(y,ps,zp2,th,r23x) - contact23x(x,ga,zp2,th,r23y))/(sqrt(2)*fabs(e3)));
		if (DEBUG)
	{
		printf("\nPhi3: %f", ph1);
	}
	return ph1;
}

/* Caculate how much to move (angle) cam 4 
 Based on desired x, y, roll, pitch, and yaw. 

Result derives from Row 1 of [ EP45 ] = [ A45 ] * [ TDS ] + theta * [ TH45 ]*/ 
double calcPhi4 (double y, double ps, double zp4, double th, double r45x, double x, double ga, double r45y, double e4){
	double ph1 = asin((contact45y(y,ps,zp4,th,r45x) + contact45x(x,ga,zp4,th,r45y))/(sqrt(2)*fabs(e4)));
		if (DEBUG)
	{
		printf("\nPhi4: %f", ph1);
	}
	return ph1;
}

/* Caculate how much to move (angle) cam 4 
 Based on desired x, y, roll, pitch, and yaw. 

Result derives from Row 2 of [ EP45 ] = [ A45 ] * [ TDS ] + theta * [ TH45 ]*/ 
double calcPhi5 (double y, double ps, double zp4, double th, double r45x, double x, double ga, double r45y, double e5){
	double ph1 = asin((contact45y(y,ps,zp4,th,r45x) - contact45x(x,ga,zp4,th,r45y))/(sqrt(2)*fabs(e5)));
		if (DEBUG)
	{
		printf("\nPhi5: %f", ph1);
	}
	return ph1;
}

/* Calculate how much to rotate every cam based on the desired x, y, roll, yaw, pitch 
   Angles are in radians */
static int calcCMS(aSubRecord *precord){
	double e1 = *(double*)precord->a;
	double e2 = *(double*)precord->b;
	double e3 = *(double*)precord->c;
	double e4 = *(double*)precord->d;
	double e5 = *(double*)precord->e;
	double zp2 = *(double*)precord->f;
	double zp4 = *(double*)precord->g;
	double rp1x = *(double*)precord->h;
	double r23x = *(double*)precord->i;
	double r23y = *(double*)precord->j;
	double r45x = *(double*)precord->k;
	double r45y = *(double*)precord->l;
	double x = *(double*)precord->m;
	double y = *(double*)precord->n;
	double th = *(double*)precord->o;
	double ps = *(double*)precord->p;
	double ga = *(double*)precord->q;
	double zrel = *(double*)precord->r;

	double phi1 = rad2deg(calcPhi1(y,ps,zp2,zrel,zp4,th,rp1x,e1));
	double phi2 = rad2deg(calcPhi2(y,ps,zp2,th,r23x,x,ga,r23y,e2));
	double phi3 = rad2deg(calcPhi3(y,ps,zp2,th,r23x,x,ga,r23y,e3));
	double phi4 = rad2deg(calcPhi4(y,ps,zp4,th,r45x,x,ga,r45y,e4));
	double phi5 = rad2deg(calcPhi5(y,ps,zp4,th,r45x,x,ga,r45y,e5));

        char msg[19];

	if (DEBUG) { 
        	printf("%.2lf %.2lf %.2lf %.2lf %.2lf\n", phi1, phi2, phi3, phi4, phi5);
	}

	*(double*)precord->vala = phi1;
	*(double*)precord->valb = phi2;
	*(double*)precord->valc = phi3;
	*(double*)precord->vald = phi4;
	*(double*)precord->vale = phi5;

	if (isnan(phi1) || isnan(phi2) || isnan(phi3) || isnan(phi4) || isnan(phi5))
	{
                printf("ERROR: invalid calculated cam angles: ");
                printf("CAM1> %f, CAM2> %f, CAM3> %f, CAM4> %f, CAM5> %f\n", phi1, phi1, phi3, phi4, phi5);
        	sprintf(msg, "Angles NOT OK");
		memcpy(precord->valf, (void*)msg, 14*sizeof(char));
		return 1;
	}
        else{
        	sprintf(msg, "Angles OK");
		memcpy(precord->valf, (void*)msg, 14*sizeof(char));
	}
	return 0;
}


epicsRegisterFunction(calcCMS);
