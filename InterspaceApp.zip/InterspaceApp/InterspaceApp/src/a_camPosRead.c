#include <epicsStdlib.h>
#include <epicsStdioRedirect.h>
#include <epicsMath.h>
#include <dbAccess.h>
#include <dbEvent.h>
#include <dbDefs.h>
#include <recGbl.h>
#include <dbCommon.h>
#include <registryFunction.h>
#include <epicsExport.h>
#include <recSup.h>
#include <aSubRecord.h>
#include <pinfo.h>
#include <alarm.h>


#define DEBUG 0 

#define MAX_LAT 1.0
#define MIN_LAT -1.0
#define MAX_VERT 1.0
#define MIN_VERT -1.0

/* FUNCTIONS FOR DIRECT KINEMATICS: FROM CAM ANGLES TO US, DS, AND QUAD CARTESIAN POSITION
Results obtained solving the following linear system (ex for upstream, cams 2 and 3)
_      _      _         _     _                                          _
| Tusx  |    | u2x  u2y  |-1 | e2*sin(phi2) - theta*(u2 dot (z cross r2)) |
|       |  = |           | * |                                            |
| Tusy  |    | u3x  u3y  |   | e3*sin(phi3) - theta*(u3 dot (z cross r3)) |
|_     _|    |_         _|   |_                                          _|

[ T ] = inv[ A23 ] * ([ EP23 ] - [ TH23 ] ) 

Where: Tusx and Tusy are upsteam x and y compoments of the displacement
u2 = [ u2x u2y ] unit vector cam 2 surface normal. u2x = u2y = 1/sqrt(2)
u3 = [ u3x u3y ] unit vector cam 3 surface normal. u3x = -u2y = 1/sqrt(2)
e2, e3 = cams eccentricity
phi2, phi3 = cams roation angles
theta = roll angle (rotation around z axis)
z = [0 0 1 ] unit vector
r2 = [r2x r2y] position of cam 2 point of contact
r3 = [r3x r3y] position of cam 3 point of contact
The origin of the frame is in the quadrupole magnet, with z along the beam and y up

NOTE:
r23y is the result of row 1 of [ A23 ]-1 * [ TH23 ]
r23x is the result of row 2 of [ A23 ]-1 * [ TH23 ]

Similarly for downstream cams 4 and 5
*/

 

/* Y displacement resulting from cam 1 rotation */
double invA1EP1y(double e1, double phi1){
	double f = fabs(e1)*sin(phi1);
	if (DEBUG)
	{
		printf("\ninvA1Ep1y: %f", f);
	}
	return f;
}

/* X displacement resulting from rotations of cams 2 and 3*/
/* Row 1 of inv[ A23 ] * [ EP23 ] */
double invA23EP23x(double e2, double phi2, double e3, double phi3){
//double alpha23x(double e2, double phi2, double e3, double phi3){
	double f = (1./sqrt(2))*(fabs(e2)*sin(phi2)-fabs(e3)*sin(phi3));
	if (DEBUG)
	{
		printf("\ninvA23EP23x: %f", f);
	}
	return f;
}

/* Y displacement resulting from rotations of cams 2 and 3*/
/* Row 2 of inv[ A23 ] * [ EP23 ] */
double invA23EP23y(double e2, double phi2, double e3, double phi3){
	double f = (1./sqrt(2))*(fabs(e2)*sin(phi2)+fabs(e3)*sin(phi3));
	if (DEBUG)
	{
		printf("\ninvA23EP23y: %f", f);
	}
	return f;
}

/* X displacement resulting from rotations of cams 4 and 5*/
/* Row 1 of inv[ A45 ] * [ EP45 ] */
double invA45EP45x(double e4, double phi4, double e5, double phi5){
	double f = (1./sqrt(2))*(fabs(e4)*sin(phi4)-fabs(e5)*sin(phi5));
	if (DEBUG)
	{
		printf("\ninvA45EP45x: %f", f);
	}
	return f;
}

/* Y displacement resulting from rotations of cams 4 and 5*/
/* Row 2 of inv[ A45 ] * [ EP45 ] */
double invA45EP45y(double e4, double phi4, double e5, double phi5){
	double f = (1./sqrt(2))*(fabs(e4)*sin(phi4)+fabs(e5)*sin(phi5));
	if (DEBUG)
	{
		printf("\ninvA45EP45y: %f", f);
	}
	return f;
}

/* Overall upstream translation from rotation of cams 2 and 3: X component */
/* Row 1 of [ T ] = inv[ A23 ] * ([ EP23 ] - [ TH23 ] ) */
double Tusx(double e2, double phi2, double e3, double phi3, double th, double r23y){
	float f = invA23EP23x(e2,phi2,e3,phi3)+th/1000.*r23y;
	if (DEBUG)
	{
		printf("\nTusx: %f", f);
	}
	return f;
}

/* Overall upstream translation from rotation of cams 2 and 3: Y component */
/* Row 2 of [ T ] = inv[ A23 ] * ([ EP23 ] - [ TH23 ] ) */
double Tusy(double e2, double phi2, double e3, double phi3, double th, double r23x){
	float f = invA23EP23y(e2,phi2,e3,phi3)-th/1000.*r23x;
	if (DEBUG)
	{
		printf("\nTusy: %f", f);
	}
	return f;
}

/* Overall downstream translation from rotation of cams 4 and 5: X component */
/* Row 1 of [ T ] = inv[ A45 ] * ([ EP45 ] - [ TH45 ] ) */
double Tdsx(double e4, double phi4, double e5, double phi5, double th, double r45y){
	float f = invA45EP45x(e4,phi4,e5,phi5)+th/1000.*r45y;
	if (DEBUG)
	{
		printf("\nTdsx: %f", f);
	}
	return f;
}


/* Overall downstream translation from rotation of cams 4 and 5: Y component */
/* Row 2 of [ T ] = inv[ A45 ] * ([ EP45 ] - [ TH45 ] ) */
double Tdsy(double e4, double phi4, double e5, double phi5, double th, double r45x){
	float f = invA45EP45y(e4,phi4,e5,phi5)-th/1000.*r45x;
	if (DEBUG)
	{
		printf("\nTdsy: %f", f);
	}
	return f;
}

/* Initialization function for all  subroutines */
static int	calcInit(aSubRecord *pgsub)
{
	return(0);
}

/* 
   Perform intermediate calculations deriving from  
   expanding the terms that only depend from the system geometry in
   [Tux, Tuy] = inv[A23]*[e2 sin(phi2) - th u2 dot (z x r2) , e3 sin(phi3) - th u3 dot (z x r3)]
   [Tux, Tuy] = inv[A23] * ([E23] + [TH23])
   Similarly for cams 4 and 5. 
   Zrel is the relative position of the three sets of cams along the z axis. 

   NOTE: See the beginning of this file for further details
*/

static int supportCalc(aSubRecord *precord) {
	double z1 =	*(double*)precord->a; 
	double z2 =	*(double*)precord->b; 
	double z4 =	*(double*)precord->c;
	double r2x =	*(double*)precord->d;
	double r2y =	*(double*)precord->e;
	double r3x =	*(double*)precord->f;
	double r3y =	*(double*)precord->g;
	double r4x =	*(double*)precord->h;
	double r4y =	*(double*)precord->i;
	double r5x =	*(double*)precord->j;
	double r5y =	*(double*)precord->k;

        double r23x = 0.5*(r3x+r2x+r3y-r2y);
        double r23y = 0.5*(r3x-r2x+r3y+r2y);
        double r45x = 0.5*(r5x+r4x+r5y-r4y);
        double r45y = 0.5*(r5x-r4x+r5y+r4y);
        double zrel = (z1-z4)/(z2-z4); 

        *(double*)precord->vala = zrel; 
        *(double*)precord->valb = r23x; 
        *(double*)precord->valc = r23y; 
        *(double*)precord->vald = r45x; 
        *(double*)precord->vale = r45y; 

	if (DEBUG) 
	{
		printf("initialized: %.2lf %.2lf %.2lf %.2lf %.2lf\n", r23x, r23y, r45x, r45y, zrel);
	}
	return(0);

} 

/* Calculate roll angle (rotation around z) from cam angles*/
static int calcRollRead(aSubRecord *precord){
	double e1 = 	*(double*)precord->a;
	double phi1 = 	*(double*)precord->b;
	double e2 = 	*(double*)precord->c;
	double phi2 = 	*(double*)precord->d;
	double e3 = 	*(double*)precord->e;
	double phi3 = 	*(double*)precord->f;
	double zrel = 	*(double*)precord->g;
	double rp1x = 	*(double*)precord->h;
	double r23x = 	*(double*)precord->i;
	double r45x = 	*(double*)precord->j;
	double e4 = 	*(double*)precord->k;
	double phi4 = 	*(double*)precord->l;
	double e5 = 	*(double*)precord->m;
	double phi5 = 	*(double*)precord->n;

	double th = 1000.*(invA1EP1y(e1,phi1) - invA23EP23y(e2,phi2,e3,phi3)*zrel - invA45EP45y(e4,phi4,e5,phi5)*(1-zrel))/(rp1x - r23x*zrel - r45x*(1-zrel));
	if (DEBUG)
	{
		printf("\nThetaCalc: %f",th);
	}
	
	*(double *)precord->valc = th;

	return(0);
}

/* Calculate X position of center (quadrupole) from upstream and downstream X positions */
/* alexmon: I would do it differently. 
X should result from the following equation where Z = 0

X(Z) = (Xds - Xus)*(Z - Zus)/(Zds - Zus) 
where ds = index 4 and us = index 2

X(0) = -Zus*(Xds - Xus)/(Zds-Zus) = (Xus*Z2 - Xds*Z2)/(Z4-Z2)

*/
static int calcXRead(aSubRecord *precord){
	double zp4 = 	*(double*)precord->a;
	double zp2 = 	*(double*)precord->b;
	double e2 = 	*(double*)precord->c;
	double phi2 = 	*(double*)precord->d;
	double e3 = 	*(double*)precord->e;
	double phi3 = 	*(double*)precord->f;
	double theta = 	*(double*)precord->g;
	double r23y = 	*(double*)precord->h;
	double e4 = 	*(double*)precord->i;
	double phi4 = 	*(double*)precord->j;
	double e5 = 	*(double*)precord->k;
	double phi5 = 	*(double*)precord->l;
	double r45y = 	*(double*)precord->m;


	//double x = (Tusx(e2,phi2,e3,phi3,theta,r23y)*zp2-Tdsx(e4,phi4,e5,phi5,theta,r45y)*zp2)/(zp4-zp2);
	double x = (Tusx(e2,phi2,e3,phi3,theta,r23y)*zp4-Tdsx(e4,phi4,e5,phi5,theta,r45y)*zp2)/(zp4-zp2);
	if (DEBUG)
	{
		printf("\nXcalc: %f",x);
	}
	
	*(double *)precord->vala = x;

	if(*(double *)precord->vala >= MAX_LAT) {
		recGblSetSevr(precord, HIHI_ALARM, MAJOR_ALARM);
	}
	else if(*(double *)precord->vala <= MIN_LAT) {
		recGblSetSevr(precord, HIHI_ALARM, MAJOR_ALARM);
	}

	return(0);
}

/* Calculate Y position of center (quadrupole) from upstream and downstream Y positions */
/* alexmon: same comment as for X */

static int calcYRead(aSubRecord *precord){
	double zp4 = 	*(double*)precord->a;
	double zp2 = 	*(double*)precord->b;
	double e2 = 	*(double*)precord->c;
	double phi2 = 	*(double*)precord->d;
	double e3 = 	*(double*)precord->e;
	double phi3 = 	*(double*)precord->f;
	double theta = 	*(double*)precord->g;
	double r23x = 	*(double*)precord->h;
	double e4 = 	*(double*)precord->i;
	double phi4 = 	*(double*)precord->j;
	double e5 = 	*(double*)precord->k;
	double phi5 = 	*(double*)precord->l;
	double r45x = 	*(double*)precord->m;


	//double y = (Tusy(e2,phi2,e3,phi3,theta,r23x)*zp2-Tdsy(e4,phi4,e5,phi5,theta,r45x)*zp2)/(zp4-zp2);
	double y = (Tusy(e2,phi2,e3,phi3,theta,r23x)*zp4-Tdsy(e4,phi4,e5,phi5,theta,r45x)*zp2)/(zp4-zp2);
	if (DEBUG)
	{
		printf("\nYcalc: %f",y);
	}
	
	*(double *)precord->valb = y;
	
	if(*(double *)precord->valb >= MAX_LAT) {
		recGblSetSevr(precord, HIHI_ALARM, MAJOR_ALARM);
	}
	else if(*(double *)precord->valb <= MIN_LAT) {
		recGblSetSevr(precord, HIHI_ALARM, MAJOR_ALARM);
	}

	return(0);
}

/* Calculate pitch angle (rotation around x) from upstream and downstream Y translations */
static int calcPitchRead(aSubRecord *precord){
	double zp4 = 	*(double*)precord->a;
	double zp2 = 	*(double*)precord->b;
	double e4 = 	*(double*)precord->c;
	double phi4 = 	*(double*)precord->d;
	double e5 = 	*(double*)precord->e;
	double phi5 = 	*(double*)precord->f;
	double theta = 	*(double*)precord->g;
	double r45x = 	*(double*)precord->h;
	double e2 = 	*(double*)precord->i;
	double phi2 = 	*(double*)precord->j;
	double e3 = 	*(double*)precord->k;
	double phi3 = 	*(double*)precord->l;
	double r23x = 	*(double*)precord->m;


	double ps = 1000.*(Tdsy(e4,phi4,e5,phi5,theta,r45x) - Tusy(e2,phi2,e3,phi3,theta,r23x))/(zp4-zp2);
	if (DEBUG)
	{
		printf("\nPitchcalc: %f",ps);
	}
	*(double *)precord->vald = ps;

	return(0);
}

/* Calculate yaw angle (rotation around y) from upsteram and downstream X translations */ 
static int calcYawRead(aSubRecord *precord){
	double zp4 = 	*(double*)precord->a;
	double zp2 = 	*(double*)precord->b;
	double e4 = 	*(double*)precord->c;
	double phi4 = 	*(double*)precord->d;
	double e5 = 	*(double*)precord->e;
	double phi5 = 	*(double*)precord->f;
	double theta = 	*(double*)precord->g;
	double r45y = 	*(double*)precord->h;
	double e2 = 	*(double*)precord->i;
	double phi2 = 	*(double*)precord->j;
	double e3 = 	*(double*)precord->k;
	double phi3 = 	*(double*)precord->l;
	double r23y = 	*(double*)precord->m;


	double ga = 1000.*(Tdsx(e4,phi4,e5,phi5,theta,r45y) - Tusx(e2,phi2,e3,phi3,theta,r23y))/(zp4-zp2);
	if (DEBUG)
	{
		printf("\nYawcalc: %f",ga);
	}
	*(double *)precord->vale = ga;

	return(0);
}
epicsRegisterFunction(calcInit);
epicsRegisterFunction(supportCalc);
epicsRegisterFunction(calcRollRead);
epicsRegisterFunction(calcXRead);
epicsRegisterFunction(calcYRead);
epicsRegisterFunction(calcPitchRead);
epicsRegisterFunction(calcYawRead);
